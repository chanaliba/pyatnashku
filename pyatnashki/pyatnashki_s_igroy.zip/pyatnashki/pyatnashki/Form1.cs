﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pyatnashki
{
    public partial class Form1 : Form
    {
        // где сейчас пустая клетка (столбец и строка в tableLayoutPanel1)
        int pustoStolb = 3;
        int pustoStroka = 3;

        int hody = 0;              // сколько ходов сделал игрок
        bool igraOkonchena = false; // чтобы после победы нельзя было двигать костяшки

        Random rnd = new Random();

        public Form1()
        {
            InitializeComponent();
        }

        // нажали на костяшку
        private void KlikPoKostyashe(object sender, EventArgs e)
        {
            if (igraOkonchena) return; // после победы двигать нельзя

            DvinutKostyashku((Button)sender);
            ProveritPobedu();
        }

        // пробуем подвинуть костяшку в пустую клетку
        private void DvinutKostyashku(Button b)
        {
            TableLayoutPanelCellPosition pos = tableLayoutPanel1.GetCellPosition(b);

            // костяшка должна стоять вплотную к пустой клетке (слева, справа, сверху или снизу)
            // если сумма разниц по столбцу и строке равна 1, значит она рядом
            if (Math.Abs(pos.Column - pustoStolb) + Math.Abs(pos.Row - pustoStroka) == 1)
            {
                // ставим костяшку на место пустой клетки
                tableLayoutPanel1.SetCellPosition(b, new TableLayoutPanelCellPosition(pustoStolb, pustoStroka));

                // а пустая клетка теперь там, где стояла костяшка
                pustoStolb = pos.Column;
                pustoStroka = pos.Row;

                hody++;
                labelHody.Text = "Ходы: " + hody;
            }
        }

        // перемешиваем костяшки
        private void Peremeshat()
        {
            igraOkonchena = false;

            // делаем много случайных ходов от собранной позиции,
            // тогда позиция точно будет решаемой
            for (int i = 0; i < 150; i++)
            {
                // собираем все костяшки, которые стоят рядом с пустой клеткой
                List<Button> sosednie = new List<Button>();
                foreach (Control c in tableLayoutPanel1.Controls)
                {
                    TableLayoutPanelCellPosition pos = tableLayoutPanel1.GetCellPosition(c);
                    if (Math.Abs(pos.Column - pustoStolb) + Math.Abs(pos.Row - pustoStroka) == 1)
                    {
                        sosednie.Add((Button)c);
                    }
                }

                // двигаем случайную из них
                DvinutKostyashku(sosednie[rnd.Next(sosednie.Count)]);
            }

            // эти ходы были не настоящие, поэтому счётчик обнуляем
            hody = 0;
            labelHody.Text = "Ходы: 0";
        }

        // проверяем, собраны ли пятнашки
        private void ProveritPobedu()
        {
            foreach (Control c in tableLayoutPanel1.Controls)
            {
                // из имени кнопки "button7" получаем номер 7
                int nomer = Convert.ToInt32(c.Name.Substring(6));

                TableLayoutPanelCellPosition pos = tableLayoutPanel1.GetCellPosition(c);

                // костяшка с номером n должна стоять в клетке ((n-1)%4, (n-1)/4)
                // например кнопка 5 -> столбец 0, строка 1
                if (pos.Column != (nomer - 1) % 4 || pos.Row != (nomer - 1) / 4)
                {
                    return; // какая-то костяшка не на своём месте, выходим
                }
            }

            // дошли до конца цикла, значит все костяшки на местах!
            igraOkonchena = true;
            MessageBox.Show("Победа! Ходов: " + hody, "Пятнашки");

            if (MessageBox.Show("Сыграть ещё раз?", "Пятнашки", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Peremeshat();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Peremeshat();
        }

        private void buttonZanovo_Click(object sender, EventArgs e)
        {
            Peremeshat();
        }
    }
}
